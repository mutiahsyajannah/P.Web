<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class= text-center>
                        <div class="col-md-12" style="font-size: 2rem; margin-top: 10px;">
                         <?php echo e(__('SELAMAT DATANG')); ?>

                        </div>
                    
                        <div style="font-size: 1rem;">
                        <?php echo e(__('F1E120011')); ?>

                        <br>
                        <?php echo e(__('Putri Fadhilah Roslin')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas CRUD Laravel PWEB\latihan_penjualan\resources\views/home.blade.php ENDPATH**/ ?>